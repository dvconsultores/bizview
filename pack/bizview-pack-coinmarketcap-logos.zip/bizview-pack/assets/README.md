# assets/ — imágenes del proyecto

`assets/coins/<SYMBOL>.png`: 483 logos de monedas a 128×128 px, del paquete
`cryptocurrency-icons` 0.18.1 (licencia CC0 1.0, ver `coins/LICENSE.md`). El nombre del archivo es
el valor de la columna `symbol` en mayúsculas, que es la clave con la que el reporte los buscará.

Estado: la importación de Bizview admite por ahora solo `.yaml .yml .md .sql .json`; esta carpeta
se usará cuando exista el soporte de imágenes en proyectos (spec 044). Hasta entonces, si la
importación rechaza el zip por estos archivos, importa `cripto-simple.zip` (sin `assets/`).

Declaración prevista en `report.yaml` (no incluida aún porque el esquema actual no la admite):

```yaml
images:
  coins: {folder: assets/coins, key: symbol}
```

Orden de búsqueda previsto: `assets/coins/<SYMBOL>.png` → imagen cacheada desde `logo_url` →
círculo con la inicial.

Monedas del top actual sin logo en este paquete (saldrán con la inicial): HYPE y otras muy recientes.
