# Fuente «coinmarketcap» — estructura (REST)

Tipo: REST · Base: configurada en Bizview (no se incluye) · Autenticación: cabecera gestionada por
Bizview (no se incluye). Rutas relativas a la base. Plan gratuito: presupuesto mensual de llamadas
limitado; con 3 peticiones cada 30 min ≈ 4.300 llamadas/mes (dentro del plan). No subir la
frecuencia sin comprobar el plan.

Generado a mano a partir de las peticiones validadas del proyecto de ejemplo. Regenerar con
`bizview describe coinmarketcap` cuando esté disponible para REST.

## Petición `listings` — GET `v1/cryptocurrency/listings/latest`

Params usados: `limit=100`, `convert=USD`, `sort=market_cap`, `sort_dir=desc`.
`records: "$.data"` (array, 100 elementos). Campos por elemento:

| JSONPath | Tipo | Nota |
|---|---|---|
| `$.id` | integer | id CMC, clave primaria; logo público: `https://s2.coinmarketcap.com/static/img/coins/64x64/<id>.png` |
| `$.name` | text | |
| `$.symbol` | text | |
| `$.cmc_rank` | integer | |
| `$.tags` | array[text] | contiene `stablecoin`, `wrapped-tokens` cuando aplica |
| `$.circulating_supply`, `$.total_supply`, `$.max_supply` | numeric (nullable) | |
| `$.num_market_pairs` | integer | |
| `$.last_updated` | timestamptz (ISO 8601) | |
| `$.quote.USD.price` | numeric | |
| `$.quote.USD.volume_24h` | numeric | |
| `$.quote.USD.percent_change_1h` / `_24h` / `_7d` / `_30d` / `_90d` | numeric (nullable) | porcentaje |
| `$.quote.USD.market_cap` | numeric | |
| `$.quote.USD.market_cap_dominance` | numeric (nullable) | |
| `$.quote.USD.fully_diluted_market_cap` | numeric (nullable) | |

## Petición `global` — GET `v1/global-metrics/quotes/latest`

Params: `convert=USD`. `records: "$.data"` (objeto, 1 elemento). Campos:

| JSONPath | Tipo |
|---|---|
| `$.btc_dominance`, `$.eth_dominance` | numeric |
| `$.active_cryptocurrencies`, `$.active_market_pairs`, `$.active_exchanges` | integer |
| `$.last_updated` | timestamptz (ISO 8601) |
| `$.quote.USD.total_market_cap` | numeric |
| `$.quote.USD.total_volume_24h` | numeric |
| `$.quote.USD.altcoin_market_cap`, `$.quote.USD.altcoin_volume_24h` | numeric |

No hay campo de open interest en este endpoint/plan.

## Petición `fear_greed` — GET `v3/fear-and-greed/latest`

`records: "$.data"` (objeto, 1 elemento). Campos:

| JSONPath | Tipo | Nota |
|---|---|---|
| `$.value` | integer 0–100 | |
| `$.value_classification` | text | Extreme fear · Fear · Neutral · Greed · Extreme greed |
| `$.update_time` | timestamptz (ISO 8601) | usar como `snapshot_at` |

## Observaciones

- No existe endpoint público del Altcoin Season Index en este plan: calcularlo desde `listings`
  (porcentaje de los 100 primeros, sin `stablecoin`/`wrapped-tokens`, cuyo `percent_change_90d`
  supera al de BTC).
- Las tres peticiones devuelven una «foto»; para historial, conservar las tomas (carga completa
  con clave `last_updated`/`snapshot_at`).
- Datos personales: ninguno.
