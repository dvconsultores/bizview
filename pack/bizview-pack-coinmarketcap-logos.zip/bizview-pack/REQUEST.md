# REQUEST.md — Lo que quiero

## Qué necesito

Un tablero cripto sencillo, de un vistazo, para usuarios no técnicos. Datos de CoinMarketCap
cada 30 minutos. Nada de gráficas de series.

## Fuente de datos

`coinmarketcap` (REST). Estructura en `sources/coinmarketcap/structure.md`: peticiones
`listings`, `global` y `fear_greed`.

## Qué muestra, en este orden

1. **Cinco activos principales** en una fila de mosaicos: Bitcoin, Ethereum, BNB, Solana, XRP.
   Cada mosaico: **logo** (de `assets/coins/<SYMBOL>.png`), símbolo y nombre, **precio en USD**
   grande, variación 24 h como insignia verde/roja con flecha, minigráfica si es posible.
   Referencia: `request/top5.png`.
2. **Índice de miedo y codicia**: medidor semicircular (termómetro) de rojo a verde, el valor
   0–100 grande en el centro y la clasificación debajo. Referencia: `request/fear-greed.png`.
3. **Índice de temporada altcoin**: valor `/100` y barra horizontal con marcador entre «Bitcoin
   season» y «Altcoin season». No hay endpoint: calcularlo desde `listings` (porcentaje de las
   100 mayores, sin stablecoins ni wrapped tokens, cuyo `percent_change_90d` supera al de BTC;
   ≥ 75 altcoin season, ≤ 25 bitcoin season). Referencia: `request/altcoin-season.png`.
4. **Tabla de monedas**: posición, logo + símbolo, nombre, precio, variación 24 h y **volumen
   24 h**. **No mostrar capitalización de mercado.** Filtro por símbolo. Referencia:
   `request/table.png`.

## Métricas (definición)

- Precio = último `price_usd` de la moneda.
- Variación 24 h = `percent_change_24h` (puntos porcentuales).
- Volumen 24 h = `volume_24h_usd`.
- Miedo y codicia = `value` y `classification` de `fear_greed`.
- Temporada altcoin = índice calculado arriba y su etiqueta.

## Períodos

Solo «hoy» (última toma). Sin comparación.

## Imágenes

`assets/coins/<SYMBOL>.png` (483 logos CC0, nombre = símbolo en mayúsculas). Si falta el logo,
círculo con la inicial. Declarar `images: {coins: {folder: assets/coins, key: symbol}}` si el
esquema lo admite; si no, dejar los logos en la carpeta y usar mosaicos KPI.

## Actualización y alcance

Cada 30 minutos (`*/30 * * * *`), zona America/Caracas; presupuesto del plan gratuito (≈ 10 000
llamadas/mes): no subir la frecuencia. Visible para admin y usuarios. PDF horizontal con los
mismos bloques.

## Lo que NO quiero

Capitalización de mercado en ninguna parte; gráficas de líneas grandes; más de una tabla.
